package com.example.smartdialer

import android.content.Context
import com.google.mlkit.vision.text.Text
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs

data class Client(
    val name: String,
    val phone: String,
    val meetingDay: Int,
    val nach: String,
    val lastPaid: String // MM/dd/yyyy
) {
    /** Red rule: day-of-month of "last paid on" is later than the meeting day. */
    val isLate: Boolean
        get() = try {
            val f = SimpleDateFormat("M/d/yyyy", Locale.US).apply { isLenient = false }
            val c = Calendar.getInstance().apply { time = f.parse(lastPaid)!! }
            c.get(Calendar.DAY_OF_MONTH) > meetingDay
        } catch (e: Exception) { false }
}

object Store {
    private const val PREF = "dialer"
    fun save(ctx: Context, list: List<Client>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("n", it.name).put("p", it.phone).put("d", it.meetingDay)
                .put("h", it.nach).put("l", it.lastPaid))
        }
        ctx.getSharedPreferences(PREF, 0).edit().putString("clients", arr.toString()).apply()
    }
    fun load(ctx: Context): List<Client> {
        val s = ctx.getSharedPreferences(PREF, 0).getString("clients", "[]")!!
        val arr = JSONArray(s)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Client(o.getString("n"), o.getString("p"), o.getInt("d"), o.getString("h"), o.getString("l"))
        }
    }
}

object SheetParser {
    private val dateRx = Regex("""\d{1,2}/\d{1,2}/\d{4}""")
    private val phoneRx = Regex("""(?<!\d)[6-9]\d{4} ?\d{5}(?!\d)""")
    private val dayRx = Regex("""(?<!\d)(\d{1,2})(?!\d)""")
    private val hasDigit = Regex("""\d""")

    fun parse(text: Text): List<Client> {
        val lines = text.textBlocks.flatMap { it.lines }.filter { it.boundingBox != null }
            .sortedBy { it.boundingBox!!.centerY() }
        // group OCR lines into table rows by vertical position
        val rows = mutableListOf<MutableList<Text.Line>>()
        for (l in lines) {
            val b = l.boundingBox!!
            val last = rows.lastOrNull()
            if (last != null && abs(last[0].boundingBox!!.centerY() - b.centerY()) < b.height() * 0.6) last.add(l)
            else rows.add(mutableListOf(l))
        }
        val out = mutableListOf<Client>()
        for (row in rows) {
            val parts = row.sortedBy { it.boundingBox!!.left }.map { it.text.trim() }
            val joined = parts.joinToString(" ")
            val phoneM = phoneRx.find(joined) ?: continue // header/other rows have no phone
            val date = dateRx.find(joined)?.value ?: ""
            val name = parts.firstOrNull { p -> p.any { it.isLetter() } && !hasDigit.containsMatchIn(p) } ?: continue
            val nach = parts.firstOrNull { it != name && it.any { c -> c.isLetter() } && !hasDigit.containsMatchIn(it) } ?: ""
            var after = joined.substring(phoneM.range.last + 1).replace(date, "")
            var day = dayRx.findAll(after).map { it.groupValues[1].toInt() }.firstOrNull { it in 1..31 }
            if (day == null) day = dayRx.findAll(joined.replace(date, "").replace(phoneM.value, ""))
                .map { it.groupValues[1].toInt() }.lastOrNull { it in 1..31 } ?: 0
            out.add(Client(name, phoneM.value.replace(" ", ""), day, nach, date))
        }
        return out
    }
}
