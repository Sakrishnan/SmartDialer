package com.example.smartdialer

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

@Suppress("DEPRECATION")
class OverlayService : Service() {
    private var view: View? = null
    private var wm: WindowManager? = null
    private var tm: TelephonyManager? = null
    private var listener: PhoneStateListener? = null
    private var sawOffhook = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        i ?: return START_NOT_STICKY
        val c = Client(
            i.getStringExtra("name") ?: "", i.getStringExtra("phone") ?: "",
            i.getIntExtra("day", 0), i.getStringExtra("nach") ?: "", i.getStringExtra("last") ?: ""
        )
        show(c)
        listenForCallEnd()
        return START_NOT_STICKY
    }

    private fun show(c: Client) {
        removeView()
        val late = c.isLate
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(if (late) Color.parseColor("#D32F2F") else Color.parseColor("#2E7D32"))
        }
        fun tv(s: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.WHITE)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        box.addView(tv(c.name, 24f, true))
        box.addView(tv("Loan day (meeting day): ${c.meetingDay}", 16f))
        box.addView(tv("NACH: ${c.nach}", 16f))
        box.addView(tv("Last paid on: ${c.lastPaid}", 16f))
        if (late) box.addView(tv("DELAYED PAYMENT", 18f, true))
        box.addView(Button(this).apply { text = "Hide"; setOnClickListener { stopSelf() } })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm!!.addView(box, lp)
        view = box
    }

    private fun listenForCallEnd() {
        tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        listener = object : PhoneStateListener() {
            override fun onCallStateChanged(state: Int, number: String?) {
                if (state == TelephonyManager.CALL_STATE_OFFHOOK) sawOffhook = true
                if (state == TelephonyManager.CALL_STATE_IDLE && sawOffhook) stopSelf()
            }
        }
        tm!!.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
    }

    private fun removeView() { view?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; view = null }

    override fun onDestroy() {
        listener?.let { tm?.listen(it, PhoneStateListener.LISTEN_NONE) }
        removeView()
        super.onDestroy()
    }
}
