package com.example.smartdialer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var listBox: LinearLayout
    private var photoUri: Uri? = null
    private var pending: Client? = null
    private var clients = listOf<Client>()

    private val takePic = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) photoUri?.let { scan(it) }
    }
    private val pickPic = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> scan(u) } }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { pending?.let { call(it) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        val bar = LinearLayout(this)
        bar.addView(Button(this).apply {
            text = "Scan sheet"
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener {
                val f = File(cacheDir, "sheet.jpg")
                photoUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                takePic.launch(photoUri)
            }
        })
        bar.addView(Button(this).apply {
            text = "From gallery"
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { pickPic.launch("image/*") }
        })
        root.addView(bar)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(listBox) })
        setContentView(root)
        clients = Store.load(this)
        render()
    }

    private fun scan(uri: Uri) {
        Toast.makeText(this, "Reading sheet…", Toast.LENGTH_SHORT).show()
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromFilePath(this, uri))
            .addOnSuccessListener {
                clients = SheetParser.parse(it)
                Store.save(this, clients)
                render()
                if (clients.isEmpty()) Toast.makeText(this, "No rows found. Try a sharper, straighter photo.", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener { Toast.makeText(this, "Scan failed", Toast.LENGTH_LONG).show() }
    }

    private fun render() {
        listBox.removeAllViews()
        for (c in clients) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 24, 16, 24) }
            row.addView(TextView(this).apply {
                text = c.name; textSize = 20f
                setTextColor(if (c.isLate) Color.parseColor("#D32F2F") else Color.parseColor("#2E7D32"))
            })
            row.addView(TextView(this).apply { text = c.phone; textSize = 14f })
            row.setOnClickListener { call(c) }
            listBox.addView(row)
        }
    }

    private fun call(c: Client) {
        pending = c
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'display over other apps', then tap the name again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val need = arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) { perms.launch(need.toTypedArray()); return }
        pending = null
        startService(Intent(this, OverlayService::class.java)
            .putExtra("name", c.name).putExtra("phone", c.phone).putExtra("day", c.meetingDay)
            .putExtra("nach", c.nach).putExtra("last", c.lastPaid))
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${c.phone}")))
    }
}
